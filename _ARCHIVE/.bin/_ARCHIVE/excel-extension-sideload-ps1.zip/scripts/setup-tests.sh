#!/usr/bin/env bash
set -euo pipefail

wget -q https://packages.microsoft.com/config/ubuntu/24.04/packages-microsoft-prod.deb
sudo dpkg -i packages-microsoft-prod.deb
sudo apt-get update
sudo apt-get install -y powershell
pwsh -NoLogo -NoProfile -Command "Register-PSRepository -Default -ErrorAction SilentlyContinue; Install-Module Pester -Force -SkipPublisherCheck"
