<#
.SYNOPSIS
  Dev-sideload an Excel Office Web Add-in by registering a WEF Developer entry in HKCU.

.DESCRIPTION
  Creates (or updates) a per-user registry entry under:
    HKCU\Software\Microsoft\Office\16.0\WEF\Developer\<AddinId>
  pointing Excel to a local manifest XML file (Type=0).
  Features:
    - Validates environment (Excel presence/version), registry writability, and manifest shape.
    - Optionally replaces missing/blank/all-zero <Id> with a new GUID (-FixManifestId).
    - Optionally bumps <Version> to force Excel to re-fetch (-BumpVersion).
    - Optional URL reachability probe for DefaultSettings/SourceLocation (skip with -SkipNetworkCheck).
    - Optional dry-run (-ValidateOnly) to perform all checks without changing anything.
    - Writes structured JSON results and a human-readable tuning log.
    - Timestamped manifest backups (unless -NoBackup).
    - Log retention pruning (-RetainDays).
    - Safe registry write with rollback on failure.

.PARAMETER ManifestPath
  Full path to the Office Web Add-in manifest (.xml).

.PARAMETER FixManifestId
  Replace a missing/blank/all-zero <Id> with a new GUID and save the manifest.

.PARAMETER BumpVersion
  Increment the 4th segment of <Version> (semver-ish) and save the manifest.

.PARAMETER NoBackup
  Skip creating a timestamped backup prior to modifying the manifest.

.PARAMETER LogPath
  File path for the JSON results log. If omitted, a timestamped file is created next to the manifest:
    <manifest>.log.<yyyyMMdd_HHmmss>.json

.PARAMETER TuningLogPath
  File path for the human-readable tuning log (plain text). If omitted, a timestamped file is created:
    <manifest>.tuning.<yyyyMMdd_HHmmss>.log

.PARAMETER RetainDays
  If > 0, delete older timestamped logs (JSON & tuning) in the manifest folder older than N days.

.PARAMETER ValidateOnly
  Perform all validations and produce logs, but DO NOT modify the manifest or registry.

.PARAMETER SkipNetworkCheck
  Skip the reachability probe for SourceLocation.

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -FixManifestId -BumpVersion

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -ValidateOnly -SkipNetworkCheck

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -LogPath "C:\logs\addin.json" -TuningLogPath "C:\logs\addin.log" -RetainDays 14

.NOTES
  Author: Erik Plachta and Chat GPT
  Script: Excel-Addin-Registry-Sideload.ps1
  Version: 0.0.1
  Requirements: PowerShell 5+, Excel (Office 16+), manifest on disk.
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [ValidateNotNullOrEmpty()]
  [string]$ManifestPath,

  [switch]$FixManifestId,
  [switch]$BumpVersion,
  [switch]$NoBackup,

  [string]$LogPath,
  [string]$TuningLogPath,

  [int]$RetainDays,

  [switch]$ValidateOnly,
  [switch]$SkipNetworkCheck
)
Import-Module -Name (Join-Path $PSScriptRoot 'AddinSideload') -Force

try {
  Invoke-AddinDevSideload @PSBoundParameters | Out-Null
}
catch {
  Write-Error $_
  exit 1
}
