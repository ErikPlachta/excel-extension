$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module (Join-Path $here '..' 'AddinSideload' 'AddinSideload.psm1') -Force
$fixture = Join-Path $here 'fixtures' 'dummy-manifest.xml'

Describe 'Manifest utilities' {
    It 'Test-ManifestBasicShape validates dummy manifest' {
        $xml = [xml](Get-Content -LiteralPath $fixture)
        $result = Test-ManifestBasicShape -Xml $xml
        $result.IsValid | Should -BeTrue
    }

    It 'Set-ManifestId replaces zero GUID' {
        $info = Get-ManifestInfo -Path $fixture
        $newId = Set-ManifestId -Xml $info.Xml -CurrentId $info.Id
        $newId | Should -Not -BeNullOrEmpty
        $newId | Should -Not -Match '00000000-0000-0000-0000-000000000000'
    }

    It 'Set-ManifestVersionBump bumps version' {
        $info = Get-ManifestInfo -Path $fixture
        $newVer = Set-ManifestVersionBump -Xml $info.Xml -CurrentVersion $info.Version
        $newVer | Should -Be '1.0.0.1'
    }
}
