# Excel Extension Sideload PowerShell

This repository provides a PowerShell module for registering a WEF Developer entry so Excel can sideload a local Office add-in manifest.
Requires Windows PowerShell 5.1 or PowerShell 7+
to run the module.

The `AddinSideload` module ships with a PowerShell module manifest and separates functionality into feature-specific scripts:

- `Private/XmlUtils.ps1` – XML helpers.
- `Private/Manifest.ps1` – manifest manipulation and validation.
- `Private/Logging.ps1` – structured and text logging utilities.
- `Private/Environment.ps1` – registry and environment checks.
- `Public/Invoke-AddinDevSideload.ps1` – main entry point.

Use the `Excel-Addin-Registry-Sideload.ps1` wrapper script to invoke the module from the command line or import the module directly:

```powershell
Import-Module (Join-Path $PSScriptRoot 'AddinSideload')
# call the main entry point
Invoke-AddinDevSideload -ManifestPath 'C:\path\to\manifest.xml' -FixManifestId -BumpVersion
```

## Testing

If PowerShell and the Pester module are not installed, run the setup script:

```bash
./scripts/setup-tests.sh
```

Pester tests validate core manifest helpers using a sample manifest located in
`tests/fixtures`. Run all tests locally with:

```powershell
pwsh -NoLogo -NoProfile -Command "Invoke-Pester -Path tests"
```

Tests also run automatically in GitHub Actions via
`.github/workflows/test.yml`, which installs Pester and executes the same
`Invoke-Pester` command on every push and pull request.

## Extensibility

The module automatically dot-sources every `*.ps1` file inside its `Private`
and `Public` directories on import. Add internal helpers under `Private` and
exported cmdlets under `Public` to extend functionality without modifying
existing files. Implement comment-based help, parameter validation, and robust
try/catch logic in each script. Logging utilities emit JSON and plain-text logs
to aid troubleshooting.
