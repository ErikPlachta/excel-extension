<#
.SYNOPSIS
  Dev-sideload an Excel Office Web Add-in by registering a WEF Developer entry in HKCU.

.DESCRIPTION
  Creates (or updates) a per-user registry entry under:
    HKCU\Software\Microsoft\Office\16.0\WEF\Developer\<AddinId>
  pointing Excel to a local manifest XML file (Type=0).
  Features:
    - Validates environment (Excel presence/version), registry writability, and manifest shape.
    - Optionally replaces missing/blank/all-zero <Id> with a new GUID (-FixManifestId).
    - Optionally bumps <Version> to force Excel to re-fetch (-BumpVersion).
    - Optional URL reachability probe for DefaultSettings/SourceLocation (skip with -SkipNetworkCheck).
    - Optional dry-run (-ValidateOnly) to perform all checks without changing anything.
    - Writes structured JSON results and a human-readable tuning log.
    - Timestamped manifest backups (unless -NoBackup).
    - Log retention pruning (-RetainDays).
    - Safe registry write with rollback on failure.

.PARAMETER ManifestPath
  Full path to the Office Web Add-in manifest (.xml).

.PARAMETER FixManifestId
  Replace a missing/blank/all-zero <Id> with a new GUID and save the manifest.

.PARAMETER BumpVersion
  Increment the 4th segment of <Version> (semver-ish) and save the manifest.

.PARAMETER NoBackup
  Skip creating a timestamped backup prior to modifying the manifest.

.PARAMETER LogPath
  File path for the JSON results log. If omitted, a timestamped file is created next to the manifest:
    <manifest>.log.<yyyyMMdd_HHmmss>.json

.PARAMETER TuningLogPath
  File path for the human-readable tuning log (plain text). If omitted, a timestamped file is created:
    <manifest>.tuning.<yyyyMMdd_HHmmss>.log

.PARAMETER RetainDays
  If > 0, delete older timestamped logs (JSON & tuning) in the manifest folder older than N days.

.PARAMETER ValidateOnly
  Perform all validations and produce logs, but DO NOT modify the manifest or registry.

.PARAMETER SkipNetworkCheck
  Skip the reachability probe for SourceLocation.

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -FixManifestId -BumpVersion

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -ValidateOnly -SkipNetworkCheck

.EXAMPLE
  .\Addin-DevSideload.ps1 -ManifestPath "C:\OfficeAddins\dev-manifest.xml" -LogPath "C:\logs\addin.json" -TuningLogPath "C:\logs\addin.log" -RetainDays 14

.NOTES
  Author: Erik Plachta and Chat GPT
  Script: Excel-Addin-Registry-Sideload.ps1
  Version: 0.0.1
  Requirements: PowerShell 5+, Excel (Office 16+), manifest on disk.
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [ValidateNotNullOrEmpty()]
  [string]$ManifestPath,

  [switch]$FixManifestId,
  [switch]$BumpVersion,
  [switch]$NoBackup,

  [string]$LogPath,
  [string]$TuningLogPath,

  [int]$RetainDays,

  [switch]$ValidateOnly,
  [switch]$SkipNetworkCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# region: Constants
$Script:ModuleVersion   = '1.4.0'
$Script:RegistryBase    = 'HKCU:\Software\Microsoft\Office\16.0\WEF\Developer'
$Script:TimestampFormat = 'yyyyMMdd_HHmmss'
# endregion

# region: Utility Functions

function Get-XmlNodeValue {
<#
.SYNOPSIS
  Gets the InnerText for a node via XPath, namespace-agnostic.

.DESCRIPTION
  Performs an XPath query using local-name() to avoid coupling to specific namespaces and returns
  the node's InnerText, or $null if not found.

.PARAMETER Xml
  Loaded [xml] document.

.PARAMETER XPath
  XPath string using local-name() where appropriate.

.EXAMPLE
  $id = Get-XmlNodeValue -Xml $xml -XPath "/*[local-name()='OfficeApp']/*[local-name()='Id']"

.OUTPUTS
  System.String
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$XPath
  )
  return $Xml.SelectSingleNode($XPath)?.InnerText
}

function Set-XmlNodeValue {
<#
.SYNOPSIS
  Sets the InnerText for a node via XPath, namespace-agnostic.

.DESCRIPTION
  Locates a node via XPath; if found, sets its InnerText to the supplied value. Throws if not found.

.PARAMETER Xml
  Loaded [xml] document.

.PARAMETER XPath
  XPath string using local-name() where appropriate.

.PARAMETER Value
  New string value to assign to InnerText.

.EXAMPLE
  Set-XmlNodeValue -Xml $xml -XPath "/*[local-name()='OfficeApp']/*[local-name()='Id']" -Value $newGuid

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$XPath,
    [Parameter(Mandatory=$true)][string]$Value
  )
  $node = $Xml.SelectSingleNode($XPath)
  if (-not $node) { throw "XPath not found: $XPath" }
  $node.InnerText = $Value
}

function Test-AllZeroGuid {
<#
.SYNOPSIS
  Tests whether a GUID string is all zeroes (00000000-0000-0000-0000-000000000000).

.DESCRIPTION
  Returns $true if the provided string matches the "all zeros" GUID pattern, otherwise $false.

.PARAMETER Id
  GUID string to test.

.EXAMPLE
  Test-AllZeroGuid -Id '00000000-0000-0000-0000-000000000000'

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param([Parameter(Mandatory=$true)][string]$Id)
  return ($Id -match '^\s*0{8}-0{4}-0{4}-0{4}-0{12}\s*$')
}

function ConvertTo-BumpedVersion {
<#
.SYNOPSIS
  Produces a version string with the 4th segment incremented.

.DESCRIPTION
  Accepts a version string in the form A[.B[.C[.D]]] and increments the D segment, padding
  missing segments as zeros. Returns "1.0.0.1" if input is missing/invalid.

.PARAMETER Version
  The original version string.

.EXAMPLE
  ConvertTo-BumpedVersion -Version '1.0.0.9'   # -> 1.0.0.10

.OUTPUTS
  System.String
#>
  [CmdletBinding()]
  param([string]$Version)
  if (-not $Version -or -not ($Version -match '^\s*\d+(\.\d+){0,3}\s*$')) { return '1.0.0.1' }
  $parts = $Version.Trim().Split('.')
  while ($parts.Count -lt 4) { $parts += '0' }
  $parts[3] = ([int]$parts[3] + 1).ToString()
  return ($parts -join '.')
}

function New-LogTargetPaths {
<#
.SYNOPSIS
  Computes default JSON and tuning log paths.

.DESCRIPTION
  If explicit LogPath/TuningLogPath are not supplied, derives timestamped filenames in the manifest
  directory using the manifest filename as a base.

.PARAMETER ManifestPath
  Path to the manifest file.

.PARAMETER JsonLogPath
  Optional explicit JSON log path.

.PARAMETER TuningLogPath
  Optional explicit tuning (text) log path.

.EXAMPLE
  $paths = New-LogTargetPaths -ManifestPath 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with properties: JsonLogPath, TuningLogPath
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [string]$JsonLogPath,
    [string]$TuningLogPath
  )
  $ts  = (Get-Date).ToString($Script:TimestampFormat)
  $dir = Split-Path -LiteralPath $ManifestPath -Parent
  $base = $ManifestPath

  if ([string]::IsNullOrWhiteSpace($JsonLogPath)) {
    $JsonLogPath = Join-Path $dir ("{0}.log.{1}.json" -f $base, $ts)
  }
  if ([string]::IsNullOrWhiteSpace($TuningLogPath)) {
    $TuningLogPath = Join-Path $dir ("{0}.tuning.{1}.log" -f $base, $ts)
  }

  foreach ($ref in @('JsonLogPath','TuningLogPath')) {
    $val = (Get-Variable $ref -Scope Local).Value
    $val = $val -replace '[:*?\"<>|]', '_'
    Set-Variable -Name $ref -Value $val -Scope Local
  }

  return [pscustomobject]@{
    JsonLogPath   = $JsonLogPath
    TuningLogPath = $TuningLogPath
  }
}

function Write-StructuredJsonLog {
<#
.SYNOPSIS
  Writes an object to JSON log with UTF-8 encoding.

.DESCRIPTION
  Serializes the provided object to JSON (Depth=6) and writes it to the specified path.

.PARAMETER Object
  Any object to serialize.

.PARAMETER Path
  Destination log file path.

.EXAMPLE
  Write-StructuredJsonLog -Object $results -Path 'C:\logs\addin.json'

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][object]$Object,
    [Parameter(Mandatory=$true)][string]$Path
  )
  $json = $Object | ConvertTo-Json -Depth 6
  $json | Out-File -LiteralPath $Path -Encoding UTF8
}

function Write-TuningTextLog {
<#
.SYNOPSIS
  Writes a human-readable tuning log.

.DESCRIPTION
  Outputs a formatted text log that includes metadata, info key-values, steps taken,
  warnings, and errors.

.PARAMETER Title
  A short title for the log.

.PARAMETER Info
  Hashtable of key-value metadata to display.

.PARAMETER Steps
  Array of steps (strings) executed.

.PARAMETER Warnings
  Array of warnings (strings) emitted.

.PARAMETER Errors
  Array of errors (strings) emitted.

.PARAMETER Path
  Destination tuning log path.

.EXAMPLE
  Write-TuningTextLog -Title 'Excel Add-in Sideload' -Info $info -Steps $steps -Warnings $warns -Errors $errs -Path 'C:\logs\tuning.log'

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$Title,
    [hashtable]$Info,
    [string[]]$Steps,
    [string[]]$Warnings,
    [string[]]$Errors,
    [Parameter(Mandatory=$true)][string]$Path
  )
  $lines = @()
  $lines += "=== $Title ==="
  $lines += "Time     : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  $lines += "User     : $env:USERDOMAIN\$env:USERNAME"
  $lines += "Machine  : $env:COMPUTERNAME"
  $lines += "Module   : Addin-DevSideload v$Script:ModuleVersion"
  $lines += ""

  if ($Info) {
    $lines += "-- Info --"
    foreach ($k in $Info.Keys) { $lines += ("{0}: {1}" -f $k, $Info[$k]) }
    $lines += ""
  }

  if ($Steps) {
    $lines += "-- Steps --"
    $lines += $Steps
    $lines += ""
  }

  if ($Warnings) {
    $lines += "-- Warnings --"
    $lines += $Warnings
    $lines += ""
  }

  if ($Errors) {
    $lines += "-- Errors --"
    $lines += $Errors
    $lines += ""
  }

  $lines -join [Environment]::NewLine | Out-File -LiteralPath $Path -Encoding UTF8
}

function Remove-OldLogs {
<#
.SYNOPSIS
  Deletes timestamped JSON/tuning logs older than N days.

.DESCRIPTION
  Searches the manifest's directory for files matching:
    *.log.yyyymmdd_hhmmss.json
    *.tuning.yyyymmdd_hhmmss.log
  and deletes those older than the specified RetainDays threshold.

.PARAMETER Directory
  Directory to scan.

.PARAMETER RetainDays
  Delete logs strictly older than this many days. If <= 0, no action is taken.

.EXAMPLE
  Remove-OldLogs -Directory 'C:\OfficeAddins' -RetainDays 14

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$Directory,
    [Parameter(Mandatory=$true)][int]$RetainDays
  )
  if ($RetainDays -le 0 -or -not (Test-Path $Directory)) { return }
  $cut = (Get-Date).AddDays(-$RetainDays)
  Get-ChildItem -LiteralPath $Directory -File |
    Where-Object {
      $_.LastWriteTime -lt $cut -and
      ($_.Name -match '\.log\.\d{8}_\d{6}\.json$' -or $_.Name -match '\.tuning\.\d{8}_\d{6}\.log$')
    } |
    ForEach-Object {
      Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

function Get-ManifestInfo {
<#
.SYNOPSIS
  Reads key metadata from an Office Web Add-in manifest.

.DESCRIPTION
  Loads the XML manifest, reads <Id>, <Version>, <DisplayName> and DefaultSettings/SourceLocation@DefaultValue.
  Uses namespace-agnostic XPath queries.

.PARAMETER Path
  Path to the manifest XML.

.EXAMPLE
  $info = Get-ManifestInfo -Path 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with: Xml, Id, Version, DisplayName, SourceLocation
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param([Parameter(Mandatory=$true)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    throw "Manifest not found: $Path"
  }

  [xml]$xml = Get-Content -LiteralPath $Path

  $xpId       = "/*[local-name()='OfficeApp']/*[local-name()='Id']"
  $xpVersion  = "/*[local-name()='OfficeApp']/*[local-name()='Version']"
  $xpDispName = "/*[local-name()='OfficeApp']/*[local-name()='DisplayName']"
  $xpSrcLoc   = "/*[local-name()='OfficeApp']/*[local-name()='DefaultSettings']/*[local-name()='SourceLocation']"

  $id     = Get-XmlNodeValue -Xml $xml -XPath $xpId
  $ver    = Get-XmlNodeValue -Xml $xml -XPath $xpVersion
  $name   = Get-XmlNodeValue -Xml $xml -XPath $xpDispName
  $src    = $xml.SelectSingleNode($xpSrcLoc)?.Attributes?.GetNamedItem('DefaultValue')?.Value

  return [pscustomobject]@{
    Xml            = $xml
    Id             = $id
    Version        = $ver
    DisplayName    = $name
    SourceLocation = $src
  }
}

function Set-ManifestId {
<#
.SYNOPSIS
  Ensures the manifest has a non-zero GUID <Id> and returns the final Id.

.DESCRIPTION
  If the current Id is missing, blank, or all-zero GUID, sets a new GUID value and
  returns it. Caller is responsible for saving the XML.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER CurrentId
  Current <Id> string from the manifest (may be $null or all-zero).

.OUTPUTS
  System.String (the final Id)
#>
  [CmdletBinding()]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [string]$CurrentId
  )
  $xpId = "/*[local-name()='OfficeApp']/*[local-name()='Id']"
  $needsNew = (-not $CurrentId) -or [string]::IsNullOrWhiteSpace($CurrentId) -or (Test-AllZeroGuid $CurrentId)
  if ($needsNew) {
    $newId = [guid]::NewGuid().ToString()
    Set-XmlNodeValue -Xml $Xml -XPath $xpId -Value $newId
    return $newId
  }
  return $CurrentId
}

function Set-ManifestVersionBump {
<#
.SYNOPSIS
  Bumps <Version> in the manifest and returns the final Version.

.DESCRIPTION
  Computes a bumped version using ConvertTo-BumpedVersion and writes it back into the XML.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER CurrentVersion
  Current <Version> string (may be $null/empty).

.OUTPUTS
  System.String (the final Version)
#>
  [CmdletBinding()]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [string]$CurrentVersion
  )
  $xpVersion = "/*[local-name()='OfficeApp']/*[local-name()='Version']"
  $newVer = ConvertTo-BumpedVersion -Version $CurrentVersion
  Set-XmlNodeValue -Xml $Xml -XPath $xpVersion -Value $newVer
  return $newVer
}

function Save-ManifestWithBackup {
<#
.SYNOPSIS
  Saves the manifest to disk with optional timestamped backup.

.DESCRIPTION
  If -NoBackup is not set, creates a timestamped backup file next to the manifest before saving.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER Path
  Path to the original manifest on disk.

.PARAMETER NoBackup
  Switch to skip backup creation.

.EXAMPLE
  Save-ManifestWithBackup -Xml $xml -Path 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with: SavedPath, BackupPath (BackupPath may be $null)
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$Path,
    [switch]$NoBackup
  )

  $backupPath = $null
  if (-not $NoBackup) {
    $backupPath = [System.IO.Path]::ChangeExtension($Path, ".backup.$([DateTime]::Now.ToString($Script:TimestampFormat)).xml")
    Copy-Item -LiteralPath $Path -Destination $backupPath -Force
  }

  $Xml.Save($Path)

  return [pscustomobject]@{
    SavedPath  = $Path
    BackupPath = $backupPath
  }
}

function New-DeveloperSideloadRegistryEntry {
<#
.SYNOPSIS
  Creates/updates the WEF Developer registry entry for sideloading.

.DESCRIPTION
  Writes the per-user registry key under:
    HKCU\Software\Microsoft\Office\16.0\WEF\Developer\<AddinId>
  with:
    ManifestPath = <Path>
    Type         = 0   (0=file path, 1=url)

.PARAMETER AddinId
  The add-in GUID (from the manifest after validation).

.PARAMETER ManifestPath
  Full path to the manifest on disk.

.PARAMETER Type
  Registry Type value. Default 0 (file path). Set to 1 to point to a URL (not typical for local dev).

.EXAMPLE
  New-DeveloperSideloadRegistryEntry -AddinId $id -ManifestPath 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  System.String (the full registry path created/updated)
#>
  [CmdletBinding(SupportsShouldProcess=$true)]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][string]$AddinId,
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [ValidateSet(0,1)][int]$Type = 0
  )

  $regPath = Join-Path $Script:RegistryBase $AddinId

  if ($PSCmdlet.ShouldProcess($regPath, "Set WEF Developer sideload entry")) {
    if (-not (Test-Path $Script:RegistryBase)) {
      New-Item -Path $Script:RegistryBase -Force | Out-Null
    }
    New-Item -Path $regPath -Force | Out-Null
    New-ItemProperty -Path $regPath -Name "ManifestPath" -Value $ManifestPath -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $regPath -Name "Type" -Value $Type -PropertyType DWord -Force | Out-Null
  }

  return $regPath
}

function Test-ExcelInstalled {
<#
.SYNOPSIS
  Verifies that Microsoft Excel Desktop is installed (Office 16+).

.DESCRIPTION
  Checks common registry locations for Excel install/version. Returns a PSCustomObject with
  IsInstalled, Version, InstallRoot, and Bitness (if determinable). Non-throwing; caller decides.

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param()

  $candidates = @(
    'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration',
    'HKLM:\SOFTWARE\Microsoft\Office\16.0\Common\InstallRoot',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Common\InstallRoot'
  )

  $info = [ordered]@{
    IsInstalled = $false
    Version     = $null
    InstallRoot = $null
    Bitness     = $null
    SourceKey   = $null
  }

  foreach ($key in $candidates) {
    if (Test-Path $key) {
      $props = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
      if ($props) {
        if ($props.ProductReleaseIds -or $props.VersionToReport) {
          $info.IsInstalled = $true
          $info.Version     = $props.VersionToReport
          $info.InstallRoot = $props.InstallationPath
          $info.SourceKey   = $key
          break
        }
        if ($props.Path) {
          $info.IsInstalled = $true
          $info.InstallRoot = $props.Path
          $info.SourceKey   = $key
          $excelExe = Join-Path $props.Path 'EXCEL.EXE'
          if (Test-Path $excelExe) {
            try { $info.Version = (Get-Item $excelExe).VersionInfo.ProductVersion } catch {}
          }
          break
        }
      }
    }
  }

  try {
    $excelPaths = @(
      "$env:ProgramFiles\Microsoft Office\root\Office16\EXCEL.EXE",
      "$env:ProgramFiles(x86)\Microsoft Office\root\Office16\EXCEL.EXE"
    )
    foreach ($p in $excelPaths) {
      if (Test-Path $p) {
        $info.Bitness = ($p -like "$env:ProgramFiles(x86)*") ? 'x86' : 'x64'
        break
      }
    }
  } catch {}

  return [pscustomobject]$info
}

function Test-RegistryWritable {
<#
.SYNOPSIS
  Validates that the WEF\Developer base path is creatable and writable.

.DESCRIPTION
  Attempts to create a temporary test key and value, then removes them. Returns $true/$false.

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param()

  $base = $Script:RegistryBase
  try {
    if (-not (Test-Path $base)) { New-Item -Path $base -Force | Out-Null }
    $test = Join-Path $base ('_TestWrite_' + [guid]::NewGuid().ToString('N'))
    New-Item -Path $test -Force | Out-Null
    New-ItemProperty -Path $test -Name 'Ping' -Value 'Pong' -PropertyType String -Force | Out-Null
    Remove-Item -Path $test -Recurse -Force
    return $true
  } catch { return $false }
}

function Test-ManifestBasicShape {
<#
.SYNOPSIS
  Validates that the manifest XML has the minimum required structure.

.DESCRIPTION
  Checks presence and basic validity of: <OfficeApp>, <Id>, <Version>,
  <DefaultSettings>/<SourceLocation @DefaultValue>. Validates GUID and version formats.
  Returns a PSCustomObject with IsValid and Issues[].

.PARAMETER Xml
  Loaded [xml] manifest.

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param([Parameter(Mandatory=$true)][xml]$Xml)

  $issues = New-Object System.Collections.Generic.List[string]

  $xpApp   = "/*[local-name()='OfficeApp']"
  $xpId    = "$xpApp/*[local-name()='Id']"
  $xpVer   = "$xpApp/*[local-name()='Version']"
  $xpSrc   = "$xpApp/*[local-name()='DefaultSettings']/*[local-name()='SourceLocation']"

  $app = $Xml.SelectSingleNode($xpApp)
  if (-not $app) { $issues.Add('Missing <OfficeApp> root.'); return [pscustomobject]@{ IsValid=$false; Issues=$issues } }

  $id  = $Xml.SelectSingleNode($xpId)?.InnerText
  $ver = $Xml.SelectSingleNode($xpVer)?.InnerText
  $src = $Xml.SelectSingleNode($xpSrc)
  $srcVal = $src?.Attributes?.GetNamedItem('DefaultValue')?.Value

  if ([string]::IsNullOrWhiteSpace($id))  { $issues.Add('Missing <Id>.') }
  elseif (-not ($id -match '^[{(]?[0-9A-Fa-f]{8}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{12}[)}]?$' -or (Test-AllZeroGuid $id))) {
    $issues.Add('Invalid GUID format in <Id>.')
  }

  if ([string]::IsNullOrWhiteSpace($ver))  { $issues.Add('Missing <Version>.') }
  elseif (-not ($ver -match '^\s*\d+(\.\d+){0,3}\s*$')) { $issues.Add('Invalid <Version> format. Expected A[.B[.C[.D]]].') }

  if (-not $src)                { $issues.Add('Missing <DefaultSettings>/<SourceLocation>.') }
  elseif (-not $srcVal)         { $issues.Add('Missing @DefaultValue on <SourceLocation>.') }
  else {
    if (-not ($srcVal -match '^https://')) {
      if (-not ($srcVal -match '^http://localhost(:\d+)?/')) {
        $issues.Add("SourceLocation must be HTTPS or http://localhost for dev. Found: $srcVal")
      }
    }
  }

  return [pscustomobject]@{ IsValid = ($issues.Count -eq 0); Issues = $issues; SourceLocation = $srcVal; Id=$id; Version=$ver }
}

function Test-UrlReachable {
<#
.SYNOPSIS
  Optionally probes a URL with a HEAD/GET to check basic reachability.

.DESCRIPTION
  Uses Invoke-WebRequest -Method Head (falls back to GET) with a short timeout.
  Returns a PSCustomObject with Reachable, StatusCode, and Error (if any). Non-throwing.

.PARAMETER Url
  URL to probe.

.PARAMETER TimeoutSec
  Timeout seconds (default 5).

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][string]$Url,
    [int]$TimeoutSec = 5
  )
  $out = [ordered]@{ Reachable=$false; StatusCode=$null; Error=$null }
  try {
    try {
      $resp = Invoke-WebRequest -Uri $Url -Method Head -UseBasicParsing -TimeoutSec $TimeoutSec
    } catch {
      $resp = Invoke-WebRequest -Uri $Url -Method Get  -UseBasicParsing -TimeoutSec $TimeoutSec
    }
    if ($resp) {
      $out.Reachable  = $true
      $out.StatusCode = $resp.StatusCode
    }
  } catch {
    $out.Error = $_.Exception.Message
  }
  return [pscustomobject]$out
}

function Test-ManifestFileReadable {
<#
.SYNOPSIS
  Ensures the manifest file is present, readable, and not exclusively locked.

.DESCRIPTION
  Opens the file with FileShare.ReadWrite to detect hard locks, and confirms UTF-8 decodability.

.PARAMETER Path
  Manifest file path.

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param([Parameter(Mandatory=$true)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
      $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8, $true)
      $null = $sr.ReadToEnd()
      $sr.Close()
    } finally { $fs.Close() }
    return $true
  } catch { return $false }
}

# endregion

# region: Orchestrator

function Invoke-AddinDevSideload {
<#
.SYNOPSIS
  Orchestrates the entire developer sideload flow and logging.

.DESCRIPTION
  Loads the manifest, validates environment/permissions/shape, optionally fixes <Id>, optionally bumps <Version>,
  saves (with optional backup), writes the WEF Developer registry entry, and emits both JSON and text logs.
  Supports dry-run (-ValidateOnly) and skipping network probe (-SkipNetworkCheck).

.PARAMETER ManifestPath
  Path to the manifest XML.

.PARAMETER FixManifestId
  Replace missing/blank/all-zero <Id> with a new GUID.

.PARAMETER BumpVersion
  Increment the fourth segment of <Version>.

.PARAMETER NoBackup
  Skip timestamped backup creation before saving.

.PARAMETER LogPath
  Explicit JSON log path (optional).

.PARAMETER TuningLogPath
  Explicit tuning text log path (optional).

.PARAMETER RetainDays
  If > 0, prune older timestamped logs in the manifest folder older than N days.

.PARAMETER ValidateOnly
  Perform validations and produce logs without modifying registry or manifest.

.PARAMETER SkipNetworkCheck
  Skip SourceLocation reachability probe.

.EXAMPLE
  Invoke-AddinDevSideload -ManifestPath 'C:\OfficeAddins\dev-manifest.xml' -FixManifestId -BumpVersion

.OUTPUTS
  PSCustomObject – structured result with _meta, parameters, manifest, registry, outcome.
#>
  [CmdletBinding(SupportsShouldProcess=$true)]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [switch]$FixManifestId,
    [switch]$BumpVersion,
    [switch]$NoBackup,
    [string]$LogPath,
    [string]$TuningLogPath,
    [int]$RetainDays,
    [switch]$ValidateOnly,
    [switch]$SkipNetworkCheck
  )

  $started = Get-Date
  $sw = [System.Diagnostics.Stopwatch]::StartNew()

  $paths    = New-LogTargetPaths -ManifestPath $ManifestPath -JsonLogPath $LogPath -TuningLogPath $TuningLogPath
  $jsonOut  = $paths.JsonLogPath
  $tuneOut  = $paths.TuningLogPath
  $steps    = New-Object System.Collections.Generic.List[string]
  $warnings = New-Object System.Collections.Generic.List[string]
  $errors   = New-Object System.Collections.Generic.List[string]

  $result = [ordered]@{
    _meta = [ordered]@{
      moduleVersion = $Script:ModuleVersion
      startedAt     = $started.ToString('o')
      user          = "$($env:USERDOMAIN)\$($env:USERNAME)"
      machine       = $env:COMPUTERNAME
    }
    parameters = [ordered]@{
      manifestPath   = $ManifestPath
      fixManifestId  = [bool]$FixManifestId
      bumpVersion    = [bool]$BumpVersion
      noBackup       = [bool]$NoBackup
      logPath        = $jsonOut
      tuningLog      = $tuneOut
      retainDays     = $RetainDays
      validateOnly   = [bool]$ValidateOnly
      skipNetworkChk = [bool]$SkipNetworkCheck
    }
    manifest = [ordered]@{
      idOriginal        = $null
      idFinal           = $null
      versionOriginal   = $null
      versionFinal      = $null
      displayName       = $null
      sourceLocation    = $null
      modified          = $false
      backupPath        = $null
      savedPath         = $null
    }
    registry = [ordered]@{
      basePath          = $Script:RegistryBase
      addinId           = $null
      regPath           = $null
      manifestPath      = $ManifestPath
      type              = 0
    }
    outcome = [ordered]@{
      success           = $false
      message           = $null
      error             = $null
      durationMs        = 0
    }
  }

  $regCreatedPath = $null

  try {
    # Environment checks
    $steps.Add("Check Excel installation")
    $xl = Test-ExcelInstalled
    if (-not $xl.IsInstalled) {
      $warnings.Add("Excel Desktop not detected. You can still write the sideload entry, but Excel won't load it.")
    } else {
      if ($xl.Version) { $steps.Add("Excel version: $($xl.Version)") }
    }

    $steps.Add("Check registry writability at $($Script:RegistryBase)")
    if (-not (Test-RegistryWritable)) {
      throw "Registry not writable at $($Script:RegistryBase). Check permissions or run as the same user Excel runs under."
    }

    $steps.Add("Check manifest file readability")
    if (-not (Test-ManifestFileReadable -Path $ManifestPath)) {
      throw "Manifest file is not readable or is locked: $ManifestPath"
    }

    # Load manifest + shape validation
    $steps.Add("Load manifest: $ManifestPath")
    $info = Get-ManifestInfo -Path $ManifestPath
    $result.manifest.idOriginal      = $info.Id
    $result.manifest.versionOriginal = $info.Version
    $result.manifest.displayName     = $info.DisplayName
    $result.manifest.sourceLocation  = $info.SourceLocation

    $steps.Add("Validate manifest basic structure")
    $shape = Test-ManifestBasicShape -Xml $info.Xml
    if (-not $shape.IsValid) {
      foreach ($i in $shape.Issues) { $errors.Add($i) }
      throw "Manifest failed shape validation. See tuning log for details."
    }

    if (-not $SkipNetworkCheck -and $shape.SourceLocation -and -not ($shape.SourceLocation -match '^http://localhost(:\d+)?/')) {
      $steps.Add("Probe SourceLocation: $($shape.SourceLocation)")
      $probe = Test-UrlReachable -Url $shape.SourceLocation -TimeoutSec 5
      if (-not $probe.Reachable) {
        $warnings.Add("SourceLocation not reachable now: $($shape.SourceLocation). Status=$($probe.StatusCode); Error=$($probe.Error)")
      }
    }

    # Optional modifications
    $finalId = $info.Id
    $finalVersion = $info.Version
    $needsSave = $false

    if ($FixManifestId -and (
        -not $info.Id -or [string]::IsNullOrWhiteSpace($info.Id) -or (Test-AllZeroGuid $info.Id)
      )) {
      if ($ValidateOnly) {
        $warnings.Add("ValidateOnly: would replace <Id> with new GUID.")
      } else {
        $steps.Add("FixManifestId: Generating new GUID for <Id>")
        $finalId = Set-ManifestId -Xml $info.Xml -CurrentId $info.Id
        $needsSave = $true
      }
    }

    if ($BumpVersion) {
      if ($ValidateOnly) {
        $warnings.Add("ValidateOnly: would bump <Version> from '$($info.Version)'.")
      } else {
        $steps.Add("BumpVersion: Incrementing <Version> from '$($info.Version)'")
        $finalVersion = Set-ManifestVersionBump -Xml $info.Xml -CurrentVersion $info.Version
        $needsSave = $true
      }
    }

    if ($needsSave -and -not $ValidateOnly) {
      $steps.Add("Save manifest (with backup=$( -not $NoBackup ))")
      $save = Save-ManifestWithBackup -Xml $info.Xml -Path $ManifestPath -NoBackup:$NoBackup
      $result.manifest.backupPath = $save.BackupPath
      $result.manifest.savedPath  = $save.SavedPath
      $result.manifest.modified   = $true
    }

    if (-not $finalId -or [string]::IsNullOrWhiteSpace($finalId)) {
      $finalId = [guid]::NewGuid().ToString()
      $warnings.Add("No usable <Id> found; using ephemeral ID for registry only: $finalId")
    }

    $result.manifest.idFinal      = $finalId
    $result.manifest.versionFinal = $finalVersion

    if ($ValidateOnly) {
      $result.outcome.success = $true
      $result.outcome.message = "Validation completed. No changes made due to -ValidateOnly."
      return [pscustomobject]$result
    }

    # Registry write (with rollback on catch)
    $steps.Add("Write WEF Developer registry entry")
    $regCreatedPath = New-DeveloperSideloadRegistryEntry -AddinId $finalId -ManifestPath $ManifestPath -Type 0 -WhatIf:$false
    $result.registry.addinId = $finalId
    $result.registry.regPath = $regCreatedPath

    $result.outcome.success = $true
    $result.outcome.message = "Sideload created. Restart Excel -> Insert -> My Add-ins -> Developer Add-ins."
  }
  catch {
    # Rollback if registry key was created
    if ($regCreatedPath -and (Test-Path $regCreatedPath)) {
      try { Remove-Item -Path $regCreatedPath -Recurse -Force } catch {}
    }
    $errors.Add($_.Exception.Message)
    if ($_.InvocationInfo) {
      $errors.Add("At {0}:{1}" -f $_.InvocationInfo.ScriptName, $_.InvocationInfo.ScriptLineNumber)
    }
    $result.outcome.success = $false
    $result.outcome.error = $_ | Out-String
  }
  finally {
    $sw.Stop()
    $result.outcome.durationMs = [int]$sw.Elapsed.TotalMilliseconds
    $result._meta.finishedAt   = (Get-Date).ToString('o')

    # Ensure log directories exist
    foreach ($p in @($jsonOut, $tuneOut)) {
      $dir = Split-Path -Path $p -Parent
      if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }

    # JSON log
    Write-StructuredJsonLog -Object $result -Path $jsonOut

    # Tuning log
    $kv = @{
      "Manifest"       = $ManifestPath
      "DisplayName"    = $result.manifest.displayName
      "SourceLocation" = $result.manifest.sourceLocation
      "Id (orig)"      = $result.manifest.idOriginal
      "Id (final)"     = $result.manifest.idFinal
      "Ver (orig)"     = $result.manifest.versionOriginal
      "Ver (final)"    = $result.manifest.versionFinal
      "Registry"       = $result.registry.regPath
      "Success"        = $result.outcome.success
      "ValidateOnly"   = $ValidateOnly
    }
    Write-TuningTextLog -Title 'Excel Add-in Developer Sideload' -Info $kv -Steps $steps -Warnings $warnings -Errors $errors -Path $tuneOut

    # Retention
    if ($RetainDays -gt 0) {
      $dir = Split-Path -LiteralPath $ManifestPath -Parent
      Remove-OldLogs -Directory $dir -RetainDays $RetainDays
    }
  }

  return [pscustomobject]$result
}

# endregion

# region: Script Entry Point
try {
  $invokeParams = @{
    ManifestPath     = $ManifestPath
    FixManifestId    = $FixManifestId
    BumpVersion      = $BumpVersion
    NoBackup         = $NoBackup
    LogPath          = $LogPath
    TuningLogPath    = $TuningLogPath
    RetainDays       = $RetainDays
    ValidateOnly     = $ValidateOnly
    SkipNetworkCheck = $SkipNetworkCheck
  }

  Invoke-AddinDevSideload @invokeParams | Out-Null
}
catch {
  Write-Error $_
  exit 1
}
# endregion
