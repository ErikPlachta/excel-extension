function Invoke-AddinDevSideload {
<#
.SYNOPSIS
  Orchestrates the entire developer sideload flow and logging.

.DESCRIPTION
  Loads the manifest, validates environment/permissions/shape, optionally fixes <Id>, optionally bumps <Version>,
  saves (with optional backup), writes the WEF Developer registry entry, and emits both JSON and text logs.
  Supports dry-run (-ValidateOnly) and skipping network probe (-SkipNetworkCheck).

.PARAMETER ManifestPath
  Path to the manifest XML.

.PARAMETER FixManifestId
  Replace missing/blank/all-zero <Id> with a new GUID.

.PARAMETER BumpVersion
  Increment the fourth segment of <Version>.

.PARAMETER NoBackup
  Skip timestamped backup creation before saving.

.PARAMETER LogPath
  Explicit JSON log path (optional).

.PARAMETER TuningLogPath
  Explicit tuning text log path (optional).

.PARAMETER RetainDays
  If > 0, prune older timestamped logs in the manifest folder older than N days.

.PARAMETER ValidateOnly
  Perform validations and produce logs without modifying registry or manifest.

.PARAMETER SkipNetworkCheck
  Skip SourceLocation reachability probe.

.EXAMPLE
  Invoke-AddinDevSideload -ManifestPath 'C:\OfficeAddins\dev-manifest.xml' -FixManifestId -BumpVersion

.OUTPUTS
  PSCustomObject – structured result with _meta, parameters, manifest, registry, outcome.
#>
  [CmdletBinding(SupportsShouldProcess=$true)]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [switch]$FixManifestId,
    [switch]$BumpVersion,
    [switch]$NoBackup,
    [string]$LogPath,
    [string]$TuningLogPath,
    [int]$RetainDays,
    [switch]$ValidateOnly,
    [switch]$SkipNetworkCheck
  )

  $started = Get-Date
  $sw = [System.Diagnostics.Stopwatch]::StartNew()

  $paths    = New-LogTargetPaths -ManifestPath $ManifestPath -JsonLogPath $LogPath -TuningLogPath $TuningLogPath
  $jsonOut  = $paths.JsonLogPath
  $tuneOut  = $paths.TuningLogPath
  $steps    = New-Object System.Collections.Generic.List[string]
  $warnings = New-Object System.Collections.Generic.List[string]
  $errors   = New-Object System.Collections.Generic.List[string]

  $result = [ordered]@{
    _meta = [ordered]@{
      moduleVersion = $Script:ModuleVersion
      startedAt     = $started.ToString('o')
      user          = "$($env:USERDOMAIN)\$($env:USERNAME)"
      machine       = $env:COMPUTERNAME
    }
    parameters = [ordered]@{
      manifestPath   = $ManifestPath
      fixManifestId  = [bool]$FixManifestId
      bumpVersion    = [bool]$BumpVersion
      noBackup       = [bool]$NoBackup
      logPath        = $jsonOut
      tuningLog      = $tuneOut
      retainDays     = $RetainDays
      validateOnly   = [bool]$ValidateOnly
      skipNetworkChk = [bool]$SkipNetworkCheck
    }
    manifest = [ordered]@{
      idOriginal        = $null
      idFinal           = $null
      versionOriginal   = $null
      versionFinal      = $null
      displayName       = $null
      sourceLocation    = $null
      modified          = $false
      backupPath        = $null
      savedPath         = $null
    }
    registry = [ordered]@{
      basePath          = $Script:RegistryBase
      addinId           = $null
      regPath           = $null
      manifestPath      = $ManifestPath
      type              = 0
    }
    outcome = [ordered]@{
      success           = $false
      message           = $null
      error             = $null
      durationMs        = 0
    }
  }

  $regCreatedPath = $null

  try {
    # Environment checks
    $steps.Add("Check Excel installation")
    $xl = Test-ExcelInstalled
    if (-not $xl.IsInstalled) {
      $warnings.Add("Excel Desktop not detected. You can still write the sideload entry, but Excel won't load it.")
    } else {
      if ($xl.Version) { $steps.Add("Excel version: $($xl.Version)") }
    }

    $steps.Add("Check registry writability at $($Script:RegistryBase)")
    if (-not (Test-RegistryWritable)) {
      throw "Registry not writable at $($Script:RegistryBase). Check permissions or run as the same user Excel runs under."
    }

    $steps.Add("Check manifest file readability")
    if (-not (Test-ManifestFileReadable -Path $ManifestPath)) {
      throw "Manifest file is not readable or is locked: $ManifestPath"
    }

    # Load manifest + shape validation
    $steps.Add("Load manifest: $ManifestPath")
    $info = Get-ManifestInfo -Path $ManifestPath
    $result.manifest.idOriginal      = $info.Id
    $result.manifest.versionOriginal = $info.Version
    $result.manifest.displayName     = $info.DisplayName
    $result.manifest.sourceLocation  = $info.SourceLocation

    $steps.Add("Validate manifest basic structure")
    $shape = Test-ManifestBasicShape -Xml $info.Xml
    if (-not $shape.IsValid) {
      foreach ($i in $shape.Issues) { $errors.Add($i) }
      throw "Manifest failed shape validation. See tuning log for details."
    }

    if (-not $SkipNetworkCheck -and $shape.SourceLocation -and -not ($shape.SourceLocation -match '^http://localhost(:\d+)?/')) {
      $steps.Add("Probe SourceLocation: $($shape.SourceLocation)")
      $probe = Test-UrlReachable -Url $shape.SourceLocation -TimeoutSec 5
      if (-not $probe.Reachable) {
        $warnings.Add("SourceLocation not reachable now: $($shape.SourceLocation). Status=$($probe.StatusCode); Error=$($probe.Error)")
      }
    }

    # Optional modifications
    $finalId = $info.Id
    $finalVersion = $info.Version
    $needsSave = $false

    if ($FixManifestId -and (
        -not $info.Id -or [string]::IsNullOrWhiteSpace($info.Id) -or (Test-AllZeroGuid $info.Id)
      )) {
      if ($ValidateOnly) {
        $warnings.Add("ValidateOnly: would replace <Id> with new GUID.")
      } else {
        $steps.Add("FixManifestId: Generating new GUID for <Id>")
        $finalId = Set-ManifestId -Xml $info.Xml -CurrentId $info.Id
        $needsSave = $true
      }
    }

    if ($BumpVersion) {
      if ($ValidateOnly) {
        $warnings.Add("ValidateOnly: would bump <Version> from '$($info.Version)'.")
      } else {
        $steps.Add("BumpVersion: Incrementing <Version> from '$($info.Version)'")
        $finalVersion = Set-ManifestVersionBump -Xml $info.Xml -CurrentVersion $info.Version
        $needsSave = $true
      }
    }

    if ($needsSave -and -not $ValidateOnly) {
      $steps.Add("Save manifest (with backup=$( -not $NoBackup ))")
      $save = Save-ManifestWithBackup -Xml $info.Xml -Path $ManifestPath -NoBackup:$NoBackup
      $result.manifest.backupPath = $save.BackupPath
      $result.manifest.savedPath  = $save.SavedPath
      $result.manifest.modified   = $true
    }

    if (-not $finalId -or [string]::IsNullOrWhiteSpace($finalId)) {
      $finalId = [guid]::NewGuid().ToString()
      $warnings.Add("No usable <Id> found; using ephemeral ID for registry only: $finalId")
    }

    $result.manifest.idFinal      = $finalId
    $result.manifest.versionFinal = $finalVersion

    if ($ValidateOnly) {
      $result.outcome.success = $true
      $result.outcome.message = "Validation completed. No changes made due to -ValidateOnly."
      return [pscustomobject]$result
    }

    # Registry write (with rollback on catch)
    $steps.Add("Write WEF Developer registry entry")
    $regCreatedPath = New-DeveloperSideloadRegistryEntry -AddinId $finalId -ManifestPath $ManifestPath -Type 0 -WhatIf:$false
    $result.registry.addinId = $finalId
    $result.registry.regPath = $regCreatedPath

    $result.outcome.success = $true
    $result.outcome.message = "Sideload created. Restart Excel -> Insert -> My Add-ins -> Developer Add-ins."
  }
  catch {
    # Rollback if registry key was created
    if ($regCreatedPath -and (Test-Path $regCreatedPath)) {
      try { Remove-Item -Path $regCreatedPath -Recurse -Force } catch {}
    }
    $errors.Add($_.Exception.Message)
    if ($_.InvocationInfo) {
      $errors.Add("At {0}:{1}" -f $_.InvocationInfo.ScriptName, $_.InvocationInfo.ScriptLineNumber)
    }
    $result.outcome.success = $false
    $result.outcome.error = $_ | Out-String
  }
  finally {
    $sw.Stop()
    $result.outcome.durationMs = [int]$sw.Elapsed.TotalMilliseconds
    $result._meta.finishedAt   = (Get-Date).ToString('o')

    # Ensure log directories exist
    foreach ($p in @($jsonOut, $tuneOut)) {
      $dir = Split-Path -Path $p -Parent
      if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }

    # JSON log
    Write-StructuredJsonLog -Object $result -Path $jsonOut

    # Tuning log
    $kv = @{
      "Manifest"       = $ManifestPath
      "DisplayName"    = $result.manifest.displayName
      "SourceLocation" = $result.manifest.sourceLocation
      "Id (orig)"      = $result.manifest.idOriginal
      "Id (final)"     = $result.manifest.idFinal
      "Ver (orig)"     = $result.manifest.versionOriginal
      "Ver (final)"    = $result.manifest.versionFinal
      "Registry"       = $result.registry.regPath
      "Success"        = $result.outcome.success
      "ValidateOnly"   = $ValidateOnly
    }
    Write-TuningTextLog -Title 'Excel Add-in Developer Sideload' -Info $kv -Steps $steps -Warnings $warnings -Errors $errors -Path $tuneOut

    # Retention
    if ($RetainDays -gt 0) {
      $dir = Split-Path -LiteralPath $ManifestPath -Parent
      Remove-OldLogs -Directory $dir -RetainDays $RetainDays
    }
  }

  return [pscustomobject]$result
}
