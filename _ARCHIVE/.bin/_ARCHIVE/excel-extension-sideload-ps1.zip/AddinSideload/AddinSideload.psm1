#requires -Version 5.1

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$manifestPath = Join-Path $PSScriptRoot 'AddinSideload.psd1'
try {
    $manifest = Import-PowerShellDataFile -Path $manifestPath
} catch {
    throw "Failed to load module manifest at '$manifestPath': $_"
}

$Script:ModuleVersion   = $manifest.ModuleVersion
$Script:RegistryBase    = 'HKCU:\Software\Microsoft\Office\16.0\WEF\Developer'
$Script:TimestampFormat = 'yyyyMMdd_HHmmss'

Get-ChildItem -Path (Join-Path $PSScriptRoot 'Private') -Filter '*.ps1' | ForEach-Object { . $_ }
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public')  -Filter '*.ps1' | ForEach-Object { . $_ }

Export-ModuleMember -Function 'Invoke-AddinDevSideload','Get-ManifestInfo','Set-ManifestId','Set-ManifestVersionBump','Test-ManifestBasicShape'
