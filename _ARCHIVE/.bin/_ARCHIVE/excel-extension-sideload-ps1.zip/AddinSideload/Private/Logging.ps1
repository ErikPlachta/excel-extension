function New-LogTargetPaths {
<#
.SYNOPSIS
  Computes default JSON and tuning log paths.

.DESCRIPTION
  If explicit LogPath/TuningLogPath are not supplied, derives timestamped filenames in the manifest
  directory using the manifest filename as a base.

.PARAMETER ManifestPath
  Path to the manifest file.

.PARAMETER JsonLogPath
  Optional explicit JSON log path.

.PARAMETER TuningLogPath
  Optional explicit tuning (text) log path.

.EXAMPLE
  $paths = New-LogTargetPaths -ManifestPath 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with properties: JsonLogPath, TuningLogPath
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [string]$JsonLogPath,
    [string]$TuningLogPath
  )
  $ts  = (Get-Date).ToString($Script:TimestampFormat)
  $dir = Split-Path -LiteralPath $ManifestPath -Parent
  $base = $ManifestPath

  if ([string]::IsNullOrWhiteSpace($JsonLogPath)) {
    $JsonLogPath = Join-Path $dir ("{0}.log.{1}.json" -f $base, $ts)
  }
  if ([string]::IsNullOrWhiteSpace($TuningLogPath)) {
    $TuningLogPath = Join-Path $dir ("{0}.tuning.{1}.log" -f $base, $ts)
  }

  foreach ($ref in @('JsonLogPath','TuningLogPath')) {
    $val = (Get-Variable $ref -Scope Local).Value
    $val = $val -replace '[:*?\"<>|]', '_'
    Set-Variable -Name $ref -Value $val -Scope Local
  }

  return [pscustomobject]@{
    JsonLogPath   = $JsonLogPath
    TuningLogPath = $TuningLogPath
  }
}

function Write-StructuredJsonLog {
<#
.SYNOPSIS
  Writes an object to JSON log with UTF-8 encoding.

.DESCRIPTION
  Serializes the provided object to JSON (Depth=6) and writes it to the specified path.

.PARAMETER Object
  Any object to serialize.

.PARAMETER Path
  Destination log file path.

.EXAMPLE
  Write-StructuredJsonLog -Object $results -Path 'C:\logs\addin.json'

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][object]$Object,
    [Parameter(Mandatory=$true)][string]$Path
  )
  $json = $Object | ConvertTo-Json -Depth 6
  $json | Out-File -LiteralPath $Path -Encoding UTF8
}

function Write-TuningTextLog {
<#
.SYNOPSIS
  Writes a human-readable tuning log.

.DESCRIPTION
  Outputs a formatted text log that includes metadata, info key-values, steps taken,
  warnings, and errors.

.PARAMETER Title
  A short title for the log.

.PARAMETER Info
  Hashtable of key-value metadata to display.

.PARAMETER Steps
  Array of steps (strings) executed.

.PARAMETER Warnings
  Array of warnings (strings) emitted.

.PARAMETER Errors
  Array of errors (strings) emitted.

.PARAMETER Path
  Destination tuning log path.

.EXAMPLE
  Write-TuningTextLog -Title 'Excel Add-in Sideload' -Info $info -Steps $steps -Warnings $warns -Errors $errs -Path 'C:\logs\tuning.log'

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$Title,
    [hashtable]$Info,
    [string[]]$Steps,
    [string[]]$Warnings,
    [string[]]$Errors,
    [Parameter(Mandatory=$true)][string]$Path
  )
  $lines = @()
  $lines += "=== $Title ==="
  $lines += "Time     : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  $lines += "User     : $env:USERDOMAIN\$env:USERNAME"
  $lines += "Machine  : $env:COMPUTERNAME"
  $lines += "Module   : Addin-DevSideload v$Script:ModuleVersion"
  $lines += ""

  if ($Info) {
    $lines += "-- Info --"
    foreach ($k in $Info.Keys) { $lines += ("{0}: {1}" -f $k, $Info[$k]) }
    $lines += ""
  }

  if ($Steps) {
    $lines += "-- Steps --"
    $lines += $Steps
    $lines += ""
  }

  if ($Warnings) {
    $lines += "-- Warnings --"
    $lines += $Warnings
    $lines += ""
  }

  if ($Errors) {
    $lines += "-- Errors --"
    $lines += $Errors
    $lines += ""
  }

  $lines -join [Environment]::NewLine | Out-File -LiteralPath $Path -Encoding UTF8
}

function Remove-OldLogs {
<#
.SYNOPSIS
  Deletes timestamped JSON/tuning logs older than N days.

.DESCRIPTION
  Searches the manifest's directory for files matching:
    *.log.yyyymmdd_hhmmss.json
    *.tuning.yyyymmdd_hhmmss.log
  and deletes those older than the specified RetainDays threshold.

.PARAMETER Directory
  Directory to scan.

.PARAMETER RetainDays
  Delete logs strictly older than this many days. If <= 0, no action is taken.

.EXAMPLE
  Remove-OldLogs -Directory 'C:\OfficeAddins' -RetainDays 14

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][string]$Directory,
    [Parameter(Mandatory=$true)][int]$RetainDays
  )
  if ($RetainDays -le 0 -or -not (Test-Path $Directory)) { return }
  $cut = (Get-Date).AddDays(-$RetainDays)
  Get-ChildItem -LiteralPath $Directory -File |
    Where-Object {
      $_.LastWriteTime -lt $cut -and
      ($_.Name -match '\.log\.\d{8}_\d{6}\.json$' -or $_.Name -match '\.tuning\.\d{8}_\d{6}\.log$')
    } |
    ForEach-Object {
      Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

