function Get-ManifestInfo {
<#
.SYNOPSIS
  Reads key metadata from an Office Web Add-in manifest.

.DESCRIPTION
  Loads the XML manifest, reads <Id>, <Version>, <DisplayName> and DefaultSettings/SourceLocation@DefaultValue.
  Uses namespace-agnostic XPath queries.

.PARAMETER Path
  Path to the manifest XML.

.EXAMPLE
  $info = Get-ManifestInfo -Path 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with: Xml, Id, Version, DisplayName, SourceLocation
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param([Parameter(Mandatory=$true)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    throw "Manifest not found: $Path"
  }

  [xml]$xml = Get-Content -LiteralPath $Path

  $xpId       = "/*[local-name()='OfficeApp']/*[local-name()='Id']"
  $xpVersion  = "/*[local-name()='OfficeApp']/*[local-name()='Version']"
  $xpDispName = "/*[local-name()='OfficeApp']/*[local-name()='DisplayName']"
  $xpSrcLoc   = "/*[local-name()='OfficeApp']/*[local-name()='DefaultSettings']/*[local-name()='SourceLocation']"

  $id     = Get-XmlNodeValue -Xml $xml -XPath $xpId
  $ver    = Get-XmlNodeValue -Xml $xml -XPath $xpVersion
  $name   = Get-XmlNodeValue -Xml $xml -XPath $xpDispName
  $src    = $xml.SelectSingleNode($xpSrcLoc)?.Attributes?.GetNamedItem('DefaultValue')?.Value

  return [pscustomobject]@{
    Xml            = $xml
    Id             = $id
    Version        = $ver
    DisplayName    = $name
    SourceLocation = $src
  }
}

function Set-ManifestId {
<#
.SYNOPSIS
  Ensures the manifest has a non-zero GUID <Id> and returns the final Id.

.DESCRIPTION
  If the current Id is missing, blank, or all-zero GUID, sets a new GUID value and
  returns it. Caller is responsible for saving the XML.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER CurrentId
  Current <Id> string from the manifest (may be $null or all-zero).

.OUTPUTS
  System.String (the final Id)
#>
  [CmdletBinding()]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [string]$CurrentId
  )
  $xpId = "/*[local-name()='OfficeApp']/*[local-name()='Id']"
  $needsNew = (-not $CurrentId) -or [string]::IsNullOrWhiteSpace($CurrentId) -or (Test-AllZeroGuid $CurrentId)
  if ($needsNew) {
    $newId = [guid]::NewGuid().ToString()
    Set-XmlNodeValue -Xml $Xml -XPath $xpId -Value $newId
    return $newId
  }
  return $CurrentId
}

function Set-ManifestVersionBump {
<#
.SYNOPSIS
  Bumps <Version> in the manifest and returns the final Version.

.DESCRIPTION
  Computes a bumped version using ConvertTo-BumpedVersion and writes it back into the XML.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER CurrentVersion
  Current <Version> string (may be $null/empty).

.OUTPUTS
  System.String (the final Version)
#>
  [CmdletBinding()]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [string]$CurrentVersion
  )
  $xpVersion = "/*[local-name()='OfficeApp']/*[local-name()='Version']"
  $newVer = ConvertTo-BumpedVersion -Version $CurrentVersion
  Set-XmlNodeValue -Xml $Xml -XPath $xpVersion -Value $newVer
  return $newVer
}

function Save-ManifestWithBackup {
<#
.SYNOPSIS
  Saves the manifest to disk with optional timestamped backup.

.DESCRIPTION
  If -NoBackup is not set, creates a timestamped backup file next to the manifest before saving.

.PARAMETER Xml
  Loaded [xml] manifest document.

.PARAMETER Path
  Path to the original manifest on disk.

.PARAMETER NoBackup
  Switch to skip backup creation.

.EXAMPLE
  Save-ManifestWithBackup -Xml $xml -Path 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  PSCustomObject with: SavedPath, BackupPath (BackupPath may be $null)
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$Path,
    [switch]$NoBackup
  )

  $backupPath = $null
  if (-not $NoBackup) {
    $backupPath = [System.IO.Path]::ChangeExtension($Path, ".backup.$([DateTime]::Now.ToString($Script:TimestampFormat)).xml")
    Copy-Item -LiteralPath $Path -Destination $backupPath -Force
  }

  $Xml.Save($Path)

  return [pscustomobject]@{
    SavedPath  = $Path
    BackupPath = $backupPath
  }
}

function Test-ManifestBasicShape {
<#
.SYNOPSIS
  Validates that the manifest XML has the minimum required structure.

.DESCRIPTION
  Checks presence and basic validity of: <OfficeApp>, <Id>, <Version>,
  <DefaultSettings>/<SourceLocation @DefaultValue>. Validates GUID and version formats.
  Returns a PSCustomObject with IsValid and Issues[].

.PARAMETER Xml
  Loaded [xml] manifest.

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param([Parameter(Mandatory=$true)][xml]$Xml)

  $issues = New-Object System.Collections.Generic.List[string]

  $xpApp   = "/*[local-name()='OfficeApp']"
  $xpId    = "$xpApp/*[local-name()='Id']"
  $xpVer   = "$xpApp/*[local-name()='Version']"
  $xpSrc   = "$xpApp/*[local-name()='DefaultSettings']/*[local-name()='SourceLocation']"

  $app = $Xml.SelectSingleNode($xpApp)
  if (-not $app) { $issues.Add('Missing <OfficeApp> root.'); return [pscustomobject]@{ IsValid=$false; Issues=$issues } }

  $id  = $Xml.SelectSingleNode($xpId)?.InnerText
  $ver = $Xml.SelectSingleNode($xpVer)?.InnerText
  $src = $Xml.SelectSingleNode($xpSrc)
  $srcVal = $src?.Attributes?.GetNamedItem('DefaultValue')?.Value

  if ([string]::IsNullOrWhiteSpace($id))  { $issues.Add('Missing <Id>.') }
  elseif (-not ($id -match '^[{(]?[0-9A-Fa-f]{8}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{4}[-]?[0-9A-Fa-f]{12}[)}]?$' -or (Test-AllZeroGuid $id))) {
    $issues.Add('Invalid GUID format in <Id>.')
  }

  if ([string]::IsNullOrWhiteSpace($ver))  { $issues.Add('Missing <Version>.') }
  elseif (-not ($ver -match '^\s*\d+(\.\d+){0,3}\s*$')) { $issues.Add('Invalid <Version> format. Expected A[.B[.C[.D]]].') }

  if (-not $src)                { $issues.Add('Missing <DefaultSettings>/<SourceLocation>.') }
  elseif (-not $srcVal)         { $issues.Add('Missing @DefaultValue on <SourceLocation>.') }
  else {
    if (-not ($srcVal -match '^https://')) {
      if (-not ($srcVal -match '^http://localhost(:\d+)?/')) {
        $issues.Add("SourceLocation must be HTTPS or http://localhost for dev. Found: $srcVal")
      }
    }
  }

  return [pscustomobject]@{ IsValid = ($issues.Count -eq 0); Issues = $issues; SourceLocation = $srcVal; Id=$id; Version=$ver }
}

function Test-ManifestFileReadable {
<#
.SYNOPSIS
  Ensures the manifest file is present, readable, and not exclusively locked.

.DESCRIPTION
  Opens the file with FileShare.ReadWrite to detect hard locks, and confirms UTF-8 decodability.

.PARAMETER Path
  Manifest file path.

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param([Parameter(Mandatory=$true)][string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
      $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8, $true)
      $null = $sr.ReadToEnd()
      $sr.Close()
    } finally { $fs.Close() }
    return $true
  } catch { return $false }
}

