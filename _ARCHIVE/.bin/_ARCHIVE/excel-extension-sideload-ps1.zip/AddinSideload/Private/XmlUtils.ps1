function Get-XmlNodeValue {
<#
.SYNOPSIS
  Gets the InnerText for a node via XPath, namespace-agnostic.

.DESCRIPTION
  Performs an XPath query using local-name() to avoid coupling to specific namespaces and returns
  the node's InnerText, or $null if not found.

.PARAMETER Xml
  Loaded [xml] document.

.PARAMETER XPath
  XPath string using local-name() where appropriate.

.EXAMPLE
  $id = Get-XmlNodeValue -Xml $xml -XPath "/*[local-name()='OfficeApp']/*[local-name()='Id']"

.OUTPUTS
  System.String
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$XPath
  )
  return $Xml.SelectSingleNode($XPath)?.InnerText
}

function Set-XmlNodeValue {
<#
.SYNOPSIS
  Sets the InnerText for a node via XPath, namespace-agnostic.

.DESCRIPTION
  Locates a node via XPath; if found, sets its InnerText to the supplied value. Throws if not found.

.PARAMETER Xml
  Loaded [xml] document.

.PARAMETER XPath
  XPath string using local-name() where appropriate.

.PARAMETER Value
  New string value to assign to InnerText.

.EXAMPLE
  Set-XmlNodeValue -Xml $xml -XPath "/*[local-name()='OfficeApp']/*[local-name()='Id']" -Value $newGuid

.OUTPUTS
  None
#>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)][xml]$Xml,
    [Parameter(Mandatory=$true)][string]$XPath,
    [Parameter(Mandatory=$true)][string]$Value
  )
  $node = $Xml.SelectSingleNode($XPath)
  if (-not $node) { throw "XPath not found: $XPath" }
  $node.InnerText = $Value
}

function Test-AllZeroGuid {
<#
.SYNOPSIS
  Tests whether a GUID string is all zeroes (00000000-0000-0000-0000-000000000000).

.DESCRIPTION
  Returns $true if the provided string matches the "all zeros" GUID pattern, otherwise $false.

.PARAMETER Id
  GUID string to test.

.EXAMPLE
  Test-AllZeroGuid -Id '00000000-0000-0000-0000-000000000000'

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param([Parameter(Mandatory=$true)][string]$Id)
  return ($Id -match '^\s*0{8}-0{4}-0{4}-0{4}-0{12}\s*$')
}

function ConvertTo-BumpedVersion {
<#
.SYNOPSIS
  Produces a version string with the 4th segment incremented.

.DESCRIPTION
  Accepts a version string in the form A[.B[.C[.D]]] and increments the D segment, padding
  missing segments as zeros. Returns "1.0.0.1" if input is missing/invalid.

.PARAMETER Version
  The original version string.

.EXAMPLE
  ConvertTo-BumpedVersion -Version '1.0.0.9'   # -> 1.0.0.10

.OUTPUTS
  System.String
#>
  [CmdletBinding()]
  param([string]$Version)
  if (-not $Version -or -not ($Version -match '^\s*\d+(\.\d+){0,3}\s*$')) { return '1.0.0.1' }
  $parts = $Version.Trim().Split('.')
  while ($parts.Count -lt 4) { $parts += '0' }
  $parts[3] = ([int]$parts[3] + 1).ToString()
  return ($parts -join '.')
}

