function New-DeveloperSideloadRegistryEntry {
<#
.SYNOPSIS
  Creates/updates the WEF Developer registry entry for sideloading.

.DESCRIPTION
  Writes the per-user registry key under:
    HKCU\Software\Microsoft\Office\16.0\WEF\Developer\<AddinId>
  with:
    ManifestPath = <Path>
    Type         = 0   (0=file path, 1=url)

.PARAMETER AddinId
  The add-in GUID (from the manifest after validation).

.PARAMETER ManifestPath
  Full path to the manifest on disk.

.PARAMETER Type
  Registry Type value. Default 0 (file path). Set to 1 to point to a URL (not typical for local dev).

.EXAMPLE
  New-DeveloperSideloadRegistryEntry -AddinId $id -ManifestPath 'C:\OfficeAddins\dev-manifest.xml'

.OUTPUTS
  System.String (the full registry path created/updated)
#>
  [CmdletBinding(SupportsShouldProcess=$true)]
  [OutputType([string])]
  param(
    [Parameter(Mandatory=$true)][string]$AddinId,
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [ValidateSet(0,1)][int]$Type = 0
  )

  $regPath = Join-Path $Script:RegistryBase $AddinId

  if ($PSCmdlet.ShouldProcess($regPath, "Set WEF Developer sideload entry")) {
    if (-not (Test-Path $Script:RegistryBase)) {
      New-Item -Path $Script:RegistryBase -Force | Out-Null
    }
    New-Item -Path $regPath -Force | Out-Null
    New-ItemProperty -Path $regPath -Name "ManifestPath" -Value $ManifestPath -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $regPath -Name "Type" -Value $Type -PropertyType DWord -Force | Out-Null
  }

  return $regPath
}

function Test-ExcelInstalled {
<#
.SYNOPSIS
  Verifies that Microsoft Excel Desktop is installed (Office 16+).

.DESCRIPTION
  Checks common registry locations for Excel install/version. Returns a PSCustomObject with
  IsInstalled, Version, InstallRoot, and Bitness (if determinable). Non-throwing; caller decides.

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param()

  $candidates = @(
    'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration',
    'HKLM:\SOFTWARE\Microsoft\Office\16.0\Common\InstallRoot',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Common\InstallRoot'
  )

  $info = [ordered]@{
    IsInstalled = $false
    Version     = $null
    InstallRoot = $null
    Bitness     = $null
    SourceKey   = $null
  }

  foreach ($key in $candidates) {
    if (Test-Path $key) {
      $props = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
      if ($props) {
        if ($props.ProductReleaseIds -or $props.VersionToReport) {
          $info.IsInstalled = $true
          $info.Version     = $props.VersionToReport
          $info.InstallRoot = $props.InstallationPath
          $info.SourceKey   = $key
          break
        }
        if ($props.Path) {
          $info.IsInstalled = $true
          $info.InstallRoot = $props.Path
          $info.SourceKey   = $key
          $excelExe = Join-Path $props.Path 'EXCEL.EXE'
          if (Test-Path $excelExe) {
            try { $info.Version = (Get-Item $excelExe).VersionInfo.ProductVersion } catch {}
          }
          break
        }
      }
    }
  }

  try {
    $excelPaths = @(
      "$env:ProgramFiles\Microsoft Office\root\Office16\EXCEL.EXE",
      "$env:ProgramFiles(x86)\Microsoft Office\root\Office16\EXCEL.EXE"
    )
    foreach ($p in $excelPaths) {
      if (Test-Path $p) {
        $info.Bitness = ($p -like "$env:ProgramFiles(x86)*") ? 'x86' : 'x64'
        break
      }
    }
  } catch {}

  return [pscustomobject]$info
}

function Test-RegistryWritable {
<#
.SYNOPSIS
  Validates that the WEF\Developer base path is creatable and writable.

.DESCRIPTION
  Attempts to create a temporary test key and value, then removes them. Returns $true/$false.

.OUTPUTS
  System.Boolean
#>
  [CmdletBinding()]
  param()

  $base = $Script:RegistryBase
  try {
    if (-not (Test-Path $base)) { New-Item -Path $base -Force | Out-Null }
    $test = Join-Path $base ('_TestWrite_' + [guid]::NewGuid().ToString('N'))
    New-Item -Path $test -Force | Out-Null
    New-ItemProperty -Path $test -Name 'Ping' -Value 'Pong' -PropertyType String -Force | Out-Null
    Remove-Item -Path $test -Recurse -Force
    return $true
  } catch { return $false }
}

function Test-UrlReachable {
<#
.SYNOPSIS
  Optionally probes a URL with a HEAD/GET to check basic reachability.

.DESCRIPTION
  Uses Invoke-WebRequest -Method Head (falls back to GET) with a short timeout.
  Returns a PSCustomObject with Reachable, StatusCode, and Error (if any). Non-throwing.

.PARAMETER Url
  URL to probe.

.PARAMETER TimeoutSec
  Timeout seconds (default 5).

.OUTPUTS
  PSCustomObject
#>
  [CmdletBinding()]
  [OutputType([pscustomobject])]
  param(
    [Parameter(Mandatory=$true)][string]$Url,
    [int]$TimeoutSec = 5
  )
  $out = [ordered]@{ Reachable=$false; StatusCode=$null; Error=$null }
  try {
    try {
      $resp = Invoke-WebRequest -Uri $Url -Method Head -UseBasicParsing -TimeoutSec $TimeoutSec
    } catch {
      $resp = Invoke-WebRequest -Uri $Url -Method Get  -UseBasicParsing -TimeoutSec $TimeoutSec
    }
    if ($resp) {
      $out.Reachable  = $true
      $out.StatusCode = $resp.StatusCode
    }
  } catch {
    $out.Error = $_.Exception.Message
  }
  return [pscustomobject]$out
}

